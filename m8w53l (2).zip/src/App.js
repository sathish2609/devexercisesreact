import React, { useState } from "react";
import "./styles.css";

function App() {
  const [count, setCount] = useState(0);
  const [input, setInput] = useState(0);
  // console.log(count);
  console.log(input);

  const invalidStatement = 'Invaild Statement!!!!!. Try Any Number Between to 0 to 100'


  const handleSubmit = (event) => {
    setInput(event.target.value);
  };

  const increaseCount = () => {
    if (input > 0 && input <= 100) {
      setCount(count + parseInt(input, 10))
    }
    if (count >= 100) {
      setCount(0)
    }
  };

  const decreaseCount = () => {
    if (count > 0) {
      setCount(count - parseInt(input, 10));
    }
  };

  const updateReset = () => {
    setCount(0);
  };

  return (
    <div>
      <div>
        <p>Counter</p>
        <h1>{count}</h1>
        <button onClick={increaseCount}>Increase</button>
        <button onClick={updateReset}>Reset</button>
        <button onClick={decreaseCount}>Decrease</button>
      </div>
      <div>
        <form>
          <label htmlFor="userinput">userinput</label>
          <input type="number" min="0" max="100" onChange={handleSubmit} />
          {(input > 100 || input < 0) && <h3 style={{color: "red"}}>{invalidStatement}</h3>}
        </form>
      </div>
    </div>
  );

  // return (
  //   <div>
  //     <p>Counter</p>
  //     <h1>{count}</h1>
  //     <button onClick={()=> setCount(count + 2)}>Increase</button>
  //     <button onClick={()=> setCount(0)}>Reset</button>
  //     <button onClick={()=> setCount(count - 2)}>Decrease</button>
  //   </div>
  // )

  // const [increment, setIncrement] = useState(0);
  // const [decrement, setDecrement] = useState(0);
  // const updateIncrement = () => {
  //   setIncrement(increment + 2)
  // }
  // const updateDecrement = () => {
  //   setDecrement(decrement - 2)
  // }
  // return (
  //   <div style={{
  //     textAlign: 'center'
  //   }}>
  //     <p style={{
  //       fontSize: 50
  //     }}><b>Counter</b></p>
  //     <h1 style={{
  //       fontSize: 50
  //     }}>{increment}</h1>
  //     <button style={{
  //       margin:10,
  //       fontSize: 20,
  //       backgroundColor: "green"
  //     }}
  //     onClick= {updateIncrement}>Increase
  //     </button>
  //     <button style={{
  //       margin: 10,
  //       fontSize: 30,
  //       backgroundColor: "yellow"
  //     }}
  //     onClick={increment}>Reset
  //     </button>
  //     <button style={{
  //       margin:10,
  //       fontSize: 20,
  //       backgroundColor: "red"
  //     }}
  //     onClick= {updateDecrement}>Decrease
  //     </button>
  //   </div>
  // )
}

export default App;
